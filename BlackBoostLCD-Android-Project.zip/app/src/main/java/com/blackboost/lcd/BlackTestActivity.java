package com.blackboost.lcd;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

public class BlackTestActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        TextView screen = new TextView(this);
        screen.setBackgroundColor(Color.BLACK);
        screen.setTextColor(Color.GRAY);
        screen.setText("NEGRO PURO  #000000\n\nToca la pantalla para salir");
        screen.setTextSize(14);
        screen.setGravity(Gravity.CENTER);
        screen.setOnClickListener(v -> finish());
        setContentView(screen);
    }
}
