package com.blackboost.lcd;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int overlayAlpha = 35;
    private TextView alphaLabel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(13, 13, 13));

        TextView title = new TextView(this);
        title.setText("BlackBoost LCD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Ajustes visuales para pantallas LCD");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subParams = params();
        subParams.bottomMargin = dp(22);
        root.addView(subtitle, subParams);

        TextView info = new TextView(this);
        info.setText("Importante: una LCD mantiene encendida su retroiluminación. Esta app no puede apagar píxeles individualmente ni convertir la pantalla en AMOLED. El filtro oscurece toda la imagen, no solo los negros.");
        info.setTextColor(Color.rgb(220, 220, 220));
        info.setTextSize(14);
        info.setPadding(dp(14), dp(14), dp(14), dp(14));
        info.setBackgroundColor(Color.rgb(31, 31, 31));
        root.addView(info, paramsWithBottom(18));

        Button test = new Button(this);
        test.setText("Abrir prueba de negro puro");
        test.setOnClickListener(v -> startActivity(new Intent(this, BlackTestActivity.class)));
        root.addView(test, paramsWithBottom(10));

        TextView overlayTitle = new TextView(this);
        overlayTitle.setText("Filtro oscuro opcional");
        overlayTitle.setTextColor(Color.WHITE);
        overlayTitle.setTextSize(18);
        overlayTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(overlayTitle, paramsWithBottom(6));

        alphaLabel = new TextView(this);
        alphaLabel.setText("Intensidad del filtro: " + overlayAlpha + "%");
        alphaLabel.setTextColor(Color.LTGRAY);
        root.addView(alphaLabel, params());

        SeekBar seek = new SeekBar(this);
        seek.setMax(70);
        seek.setProgress(overlayAlpha);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean user) {
                overlayAlpha = value;
                alphaLabel.setText("Intensidad del filtro: " + value + "%");
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        root.addView(seek, paramsWithBottom(8));

        Button enable = new Button(this);
        enable.setText("Activar filtro sobre otras apps");
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                Intent i = new Intent(this, DimOverlayService.class);
                i.setAction(DimOverlayService.ACTION_SHOW);
                i.putExtra(DimOverlayService.EXTRA_ALPHA, overlayAlpha);
                startService(i);
            }
        });
        root.addView(enable, paramsWithBottom(8));

        Button update = new Button(this);
        update.setText("Actualizar intensidad del filtro");
        update.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                Intent i = new Intent(this, DimOverlayService.class);
                i.setAction(DimOverlayService.ACTION_SHOW);
                i.putExtra(DimOverlayService.EXTRA_ALPHA, overlayAlpha);
                startService(i);
            } else {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        root.addView(update, paramsWithBottom(8));

        Button off = new Button(this);
        off.setText("Desactivar filtro");
        off.setOnClickListener(v -> stopService(new Intent(this, DimOverlayService.class)));
        root.addView(off, paramsWithBottom(18));

        TextView note = new TextView(this);
        note.setText("Consejo: usa un fondo #000000 y reduce el brillo del teléfono a un nivel cómodo. El filtro puede dificultar leer textos y ver detalles.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(13);
        root.addView(note, params());

        setContentView(root);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams paramsWithBottom(int bottom) {
        LinearLayout.LayoutParams p = params();
        p.bottomMargin = dp(bottom);
        return p;
    }
}
