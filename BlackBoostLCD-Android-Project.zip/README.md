# BlackBoost LCD

Proyecto Android Java básico para probar negro puro y una superposición oscura ajustable.

## Limitación técnica
Una superposición negra semitransparente oscurece toda la pantalla por igual. No detecta regiones negras de otras apps ni apaga píxeles individuales. Android no ofrece a una app común control sobre la retroiluminación por zonas de una pantalla LCD.

## Compilar
- Abre la carpeta del proyecto en Android Studio (en un ordenador).
- Usa JDK 17 y permite que Gradle sincronice el proyecto.
- Ve a Build > Build APK(s).
- El APK de depuración normalmente aparece en `app/build/outputs/apk/debug/app-debug.apk`.

Android Studio no se instala ni ejecuta de forma normal en un teléfono Android. Para trabajar solo desde el móvil, necesitas una herramienta compatible con Android o un servicio de compilación remoto que acepte proyectos Gradle.

## Permiso de superposición
Al pulsar "Activar filtro sobre otras apps", Android abre la pantalla del permiso especial "Mostrar sobre otras aplicaciones". Actívalo para BlackBoost LCD y vuelve a la app. Pulsa de nuevo el botón. Para quitarlo, vuelve a la app y pulsa "Desactivar filtro".
