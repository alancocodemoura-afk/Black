package com.blackboost.lcd;

/** Shaders GLSL ES 1.00 (compatibles con cualquier GPU OpenGL ES 2.0+, incluida la Mali del A14 5G). */
final class Shaders {
    private Shaders() {}

    static final String VERTEX = """
            attribute vec2 aPos;
            attribute vec2 aTex;
            uniform vec2 uScale;
            uniform mat4 uTexMat;
            varying vec2 vTex;
            void main() {
                gl_Position = vec4(aPos * uScale, 0.0, 1.0);
                vTex = (uTexMat * vec4(aTex, 0.0, 1.0)).xy;
            }
            """;

    private static final String BODY = """
            varying vec2 vTex;
            uniform float uEnabled;
            uniform float uThr;      // umbral de luminancia (0..1)
            uniform float uGamma;    // exponente de la curva en la zona oscura (>=1)
            uniform float uFloor;    // nivel de negro extra (solo Deep Black)
            uniform float uProtect;  // protección de color (0..1)
            uniform float uSplit;
            uniform float uSeed;
            uniform float uMode;     // 0 procesado, 1 dividido, 2 mapa de cambios
            uniform vec2 uRes;

            float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

            vec3 process(vec3 c) {
                float y = dot(c, vec3(0.2126, 0.7152, 0.0722));
                // Negro digital y todo lo que está por encima del umbral: intactos.
                if (y <= 0.0 || y >= uThr) return c;
                float t = y / uThr;                         // 0..1 dentro de la zona oscura
                float yc = uThr * pow(t, uGamma);           // curva de toe: 0->0, uThr->uThr
                float s = smoothstep(0.6, 1.0, t);          // empalme suave con la identidad
                float yo = mix(yc, y, s);
                yo = max(yo - uFloor * (1.0 - smoothstep(0.0, 1.0, t)), 0.0);
                float g = yo / y;                           // ganancia por píxel (<= 1)
                // Protección de color: los tonos saturados cerca del umbral se oscurecen menos.
                float mx = max(c.r, max(c.g, c.b));
                float mn = min(c.r, min(c.g, c.b));
                float sat = (mx - mn) / max(mx, 0.0001);
                float keep = uProtect * smoothstep(0.25, 0.7, sat) * smoothstep(0.3, 0.8, t);
                g = mix(g, 1.0, keep);
                vec3 o = c * g;                             // escalar RGB conserva el matiz
                // Dither triangular muy leve solo en la zona tocada para evitar bandas.
                float n = (hash(gl_FragCoord.xy + uSeed) + hash(gl_FragCoord.yx * 1.37 + uSeed * 1.7) - 1.0) / 255.0;
                o += n * smoothstep(0.0, 0.02, y) * (1.0 - s);
                return clamp(o, 0.0, 1.0);
            }

            void main() {
                vec3 src = texture2D(uTex, vTex).rgb;
                vec3 res = (uEnabled > 0.5) ? process(src) : src;
                vec3 outc = res;
                if (uMode > 1.5) {
                    float l = dot(src, vec3(0.2126, 0.7152, 0.0722));
                    float d = length(res - src);
                    outc = vec3(l * 0.4) + vec3(1.0, 0.1, 0.8) * clamp(d * 20.0, 0.0, 1.0);
                } else if (uMode > 0.5) {
                    float x = gl_FragCoord.x / uRes.x;
                    outc = (x < uSplit) ? src : res;
                    if (abs(x - uSplit) * uRes.x < 1.5) outc = vec3(1.0);
                }
                gl_FragColor = vec4(outc, 1.0);
            }
            """;

    static String fragment(boolean external) {
        String head = external
                ? "#extension GL_OES_EGL_image_external : require\nprecision highp float;\nuniform samplerExternalOES uTex;\n"
                : "precision highp float;\nuniform sampler2D uTex;\n";
        return head + BODY;
    }
}
