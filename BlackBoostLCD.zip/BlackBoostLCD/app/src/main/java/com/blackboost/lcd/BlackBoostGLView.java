package com.blackboost.lcd;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Vista OpenGL ES 2.0 que dibuja un video (textura externa OES alimentada por ExoPlayer)
 * o una imagen (textura 2D) aplicando la curva tonal selectiva en el fragment shader.
 */
public class BlackBoostGLView extends GLSurfaceView {
    private static final String TAG = "BlackBoostGL";

    public interface VideoSurfaceListener { void onVideoSurface(Surface surface); }

    private volatile ToneParams params = new ToneParams();
    private final GlRenderer renderer = new GlRenderer();
    private final Handler main = new Handler(Looper.getMainLooper());
    private VideoSurfaceListener listener;
    private volatile Surface currentSurface;
    private volatile boolean videoMode = false;
    private volatile float contentAspect = 16f / 9f;
    private volatile Bitmap bitmap;
    private final AtomicBoolean bitmapDirty = new AtomicBoolean(false);

    public BlackBoostGLView(Context c, AttributeSet a) {
        super(c, a);
        setEGLContextClientVersion(2);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    public void setParams(ToneParams p) { params = p; requestRender(); }
    public void refresh() { requestRender(); }

    public void setVideoSurfaceListener(VideoSurfaceListener l) {
        listener = l;
        Surface s = currentSurface;
        if (l != null && s != null) l.onVideoSurface(s);
    }

    public void useVideo() { videoMode = true; requestRender(); }

    public void setVideoSize(int w, int h, float pixelRatio) {
        if (w > 0 && h > 0) contentAspect = (w * (pixelRatio > 0 ? pixelRatio : 1f)) / h;
        requestRender();
    }

    public void setImage(Bitmap b) {
        bitmap = b;
        videoMode = false;
        contentAspect = (float) b.getWidth() / b.getHeight();
        bitmapDirty.set(true);
        requestRender();
    }

    @Override public void onPause() {
        currentSurface = null;
        super.onPause();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        ToneParams p = params;
        if (p.mode == ToneParams.MODE_SPLIT && getWidth() > 0) {
            p.split = Math.max(0f, Math.min(1f, e.getX() / getWidth()));
            requestRender();
            return true;
        }
        return super.onTouchEvent(e);
    }

    // ------------------------------------------------------------------ GL

    private static final class Prog {
        int id, aPos, aTex, uTex, uScale, uTexMat, uEnabled, uThr, uGamma, uFloor, uProtect, uSplit, uSeed, uMode, uRes;

        Prog(String vs, String fs) {
            int v = compile(GLES20.GL_VERTEX_SHADER, vs), f = compile(GLES20.GL_FRAGMENT_SHADER, fs);
            id = GLES20.glCreateProgram();
            GLES20.glAttachShader(id, v);
            GLES20.glAttachShader(id, f);
            GLES20.glLinkProgram(id);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(id, GLES20.GL_LINK_STATUS, ok, 0);
            if (ok[0] == 0) Log.e(TAG, "link: " + GLES20.glGetProgramInfoLog(id));
            aPos = GLES20.glGetAttribLocation(id, "aPos");
            aTex = GLES20.glGetAttribLocation(id, "aTex");
            uTex = u("uTex"); uScale = u("uScale"); uTexMat = u("uTexMat"); uEnabled = u("uEnabled");
            uThr = u("uThr"); uGamma = u("uGamma"); uFloor = u("uFloor"); uProtect = u("uProtect");
            uSplit = u("uSplit"); uSeed = u("uSeed"); uMode = u("uMode"); uRes = u("uRes");
        }

        int u(String n) { return GLES20.glGetUniformLocation(id, n); }

        static int compile(int type, String src) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, src);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) Log.e(TAG, "shader: " + GLES20.glGetShaderInfoLog(s));
            return s;
        }
    }

    private final class GlRenderer implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
        private final float[] texMat = new float[16];
        private final float[] flip = {1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1};
        private final float[] ident = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
        private final AtomicBoolean frame = new AtomicBoolean(false);
        private Prog oes, tex2d;
        private int oesTex, imgTex, w = 1, h = 1;
        private SurfaceTexture st;
        private Surface surface;
        private boolean hasFrame, hasImage;
        private float seed;
        private final FloatBuffer quad;

        GlRenderer() {
            float[] q = {-1, -1, 0, 0, 1, -1, 1, 0, -1, 1, 0, 1, 1, 1, 1, 1};
            quad = ByteBuffer.allocateDirect(q.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            quad.put(q).position(0);
            System.arraycopy(ident, 0, texMat, 0, 16);
        }

        @Override public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
            oes = new Prog(Shaders.VERTEX, Shaders.fragment(true));
            tex2d = new Prog(Shaders.VERTEX, Shaders.fragment(false));
            int[] t = new int[2];
            GLES20.glGenTextures(2, t, 0);
            oesTex = t[0];
            imgTex = t[1];
            setup(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex);
            setup(GLES20.GL_TEXTURE_2D, imgTex);
            try { if (surface != null) surface.release(); if (st != null) st.release(); } catch (RuntimeException ignored) {}
            st = new SurfaceTexture(oesTex);
            st.setOnFrameAvailableListener(this);
            surface = new Surface(st);
            hasFrame = false;
            hasImage = false;
            if (bitmap != null) bitmapDirty.set(true);
            final Surface s = surface;
            currentSurface = s;
            main.post(() -> { VideoSurfaceListener l = listener; if (l != null) l.onVideoSurface(s); });
        }

        private void setup(int target, int tex) {
            GLES20.glBindTexture(target, tex);
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        }

        @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
            w = Math.max(1, width);
            h = Math.max(1, height);
            GLES20.glViewport(0, 0, w, h);
        }

        @Override public void onFrameAvailable(SurfaceTexture s) {
            frame.set(true);
            requestRender();
        }

        @Override public void onDrawFrame(GL10 gl) {
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            boolean video = videoMode;
            if (video) {
                if (frame.getAndSet(false) && st != null) {
                    try { st.updateTexImage(); st.getTransformMatrix(texMat); hasFrame = true; }
                    catch (RuntimeException e) { Log.w(TAG, "updateTexImage", e); }
                }
                if (!hasFrame) return;
            } else {
                if (bitmapDirty.getAndSet(false)) {
                    Bitmap b = bitmap;
                    if (b != null && !b.isRecycled()) {
                        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, imgTex);
                        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
                        hasImage = true;
                    }
                }
                if (!hasImage) return;
            }

            ToneParams q = params;
            Prog p = video ? oes : tex2d;
            GLES20.glUseProgram(p.id);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(video ? GLES11Ext.GL_TEXTURE_EXTERNAL_OES : GLES20.GL_TEXTURE_2D, video ? oesTex : imgTex);
            GLES20.glUniform1i(p.uTex, 0);

            float va = (float) w / h, ca = contentAspect, sx = 1f, sy = 1f;
            if (ca > va) sy = va / ca; else sx = ca / va;
            GLES20.glUniform2f(p.uScale, sx, sy);
            GLES20.glUniformMatrix4fv(p.uTexMat, 1, false, video ? texMat : flip, 0);

            float inten = q.intensity / 100f;
            float gamma = 1f + 2f * inten + (q.deepBlack ? 0.8f : 0f);
            float thr = (q.threshold / 100f) * (q.deepBlack ? 1.15f : 1f);
            seed = (seed + 1f) % 997f;
            GLES20.glUniform1f(p.uEnabled, q.enabled ? 1f : 0f);
            GLES20.glUniform1f(p.uThr, thr);
            GLES20.glUniform1f(p.uGamma, gamma);
            GLES20.glUniform1f(p.uFloor, q.deepBlack ? 0.02f : 0f);
            GLES20.glUniform1f(p.uProtect, q.protect / 100f);
            GLES20.glUniform1f(p.uSplit, q.split);
            GLES20.glUniform1f(p.uSeed, seed);
            GLES20.glUniform1f(p.uMode, q.mode);
            GLES20.glUniform2f(p.uRes, w, h);

            quad.position(0);
            GLES20.glEnableVertexAttribArray(p.aPos);
            GLES20.glVertexAttribPointer(p.aPos, 2, GLES20.GL_FLOAT, false, 16, quad);
            quad.position(2);
            GLES20.glEnableVertexAttribArray(p.aTex);
            GLES20.glVertexAttribPointer(p.aTex, 2, GLES20.GL_FLOAT, false, 16, quad);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(p.aPos);
            GLES20.glDisableVertexAttribArray(p.aTex);
        }
    }
}
