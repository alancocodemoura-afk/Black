package com.blackboost.lcd;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private final ActivityResultLauncher<String> pickVideo =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> open(ViewerActivity.TYPE_VIDEO, uri));
    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> open(ViewerActivity.TYPE_IMAGE, uri));

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnVideo).setOnClickListener(v -> pickVideo.launch("video/*"));
        findViewById(R.id.btnImage).setOnClickListener(v -> pickImage.launch("image/*"));
        findViewById(R.id.btnTest).setOnClickListener(v -> open(ViewerActivity.TYPE_TEST, null));
        findViewById(R.id.btnInfo).setOnClickListener(v -> startActivity(new Intent(this, InfoActivity.class)));
    }

    private void open(String type, Uri uri) {
        if (uri == null && !ViewerActivity.TYPE_TEST.equals(type)) return;
        Intent i = new Intent(this, ViewerActivity.class);
        i.putExtra(ViewerActivity.EXTRA_TYPE, type);
        if (uri != null) {
            i.setData(uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        startActivity(i);
    }
}
