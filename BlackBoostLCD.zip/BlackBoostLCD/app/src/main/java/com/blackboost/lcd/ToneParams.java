package com.blackboost.lcd;

import android.content.Context;
import android.content.SharedPreferences;

/** Parámetros de la curva tonal. Se leen desde el hilo GL, por eso son volatile. */
public final class ToneParams {
    public static final int MODE_PROCESSED = 0, MODE_SPLIT = 1, MODE_DIFF = 2;
    public static final float DEF_INTENSITY = 60f;   // %
    public static final float DEF_THRESHOLD = 15f;   // % de luminancia
    public static final float DEF_PROTECT = 50f;     // %

    public volatile boolean enabled = true;
    public volatile boolean deepBlack = false;
    public volatile float intensity = DEF_INTENSITY;
    public volatile float threshold = DEF_THRESHOLD;
    public volatile float protect = DEF_PROTECT;
    public volatile int mode = MODE_PROCESSED;   // no se persiste
    public volatile float split = 0.5f;          // posición 0..1 del divisor

    private static final String PREFS = "blackboost";

    public void load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        enabled = p.getBoolean("enabled", true);
        deepBlack = p.getBoolean("deep", false);
        intensity = p.getFloat("intensity", DEF_INTENSITY);
        threshold = p.getFloat("threshold", DEF_THRESHOLD);
        protect = p.getFloat("protect", DEF_PROTECT);
    }

    public void save(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("enabled", enabled).putBoolean("deep", deepBlack)
                .putFloat("intensity", intensity).putFloat("threshold", threshold)
                .putFloat("protect", protect).apply();
    }

    public void reset() {
        enabled = true;
        deepBlack = false;
        intensity = DEF_INTENSITY;
        threshold = DEF_THRESHOLD;
        protect = DEF_PROTECT;
        mode = MODE_PROCESSED;
        split = 0.5f;
    }
}
