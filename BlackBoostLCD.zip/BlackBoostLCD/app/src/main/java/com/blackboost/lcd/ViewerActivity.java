package com.blackboost.lcd;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ViewerActivity extends AppCompatActivity {
    public static final String EXTRA_TYPE = "type";
    public static final String TYPE_VIDEO = "video", TYPE_IMAGE = "image", TYPE_TEST = "test";

    private final ToneParams params = new ToneParams();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private BlackBoostGLView gl;
    private ExoPlayer player;
    private boolean wasPlaying = true;
    private boolean userSeeking = false;
    private String type;

    private MaterialSwitch swEnabled, swDeep;
    private Slider sInt, sThr, sProt;
    private TextView lblInt, lblThr, lblProt, legend, badge;
    private Button btnPlay;
    private SeekBar seek;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null) {
                long d = player.getDuration();
                if (d > 0) seek.setMax((int) d);
                if (!userSeeking) seek.setProgress((int) player.getCurrentPosition());
            }
            ui.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_viewer);
        gl = findViewById(R.id.glView);
        swEnabled = findViewById(R.id.swEnabled);
        swDeep = findViewById(R.id.swDeep);
        sInt = findViewById(R.id.sliderIntensity);
        sThr = findViewById(R.id.sliderThreshold);
        sProt = findViewById(R.id.sliderProtect);
        lblInt = findViewById(R.id.lblIntensity);
        lblThr = findViewById(R.id.lblThreshold);
        lblProt = findViewById(R.id.lblProtect);
        legend = findViewById(R.id.txtLegend);
        badge = findViewById(R.id.txtBadge);
        btnPlay = findViewById(R.id.btnPlay);
        seek = findViewById(R.id.seekBar);

        params.load(this);
        gl.setParams(params);
        setupControls();

        type = getIntent().getStringExtra(EXTRA_TYPE);
        Uri uri = getIntent().getData();
        if (TYPE_VIDEO.equals(type) && uri != null) startVideo(uri);
        else {
            findViewById(R.id.videoBar).setVisibility(View.GONE);
            if (TYPE_IMAGE.equals(type) && uri != null) loadImage(uri);
            else gl.setImage(TestPattern.generate());
        }
    }

    private void setupControls() {
        swEnabled.setOnCheckedChangeListener((v, c) -> { params.enabled = c; gl.refresh(); });
        swDeep.setOnCheckedChangeListener((v, c) -> { params.deepBlack = c; gl.refresh(); });
        sInt.addOnChangeListener((s, v, u) -> { params.intensity = v; updateLabels(); gl.refresh(); });
        sThr.addOnChangeListener((s, v, u) -> { params.threshold = v; updateLabels(); gl.refresh(); });
        sProt.addOnChangeListener((s, v, u) -> { params.protect = v; updateLabels(); gl.refresh(); });

        com.google.android.material.button.MaterialButtonToggleGroup g = findViewById(R.id.toggleMode);
        g.check(R.id.btnModeProc);
        g.addOnButtonCheckedListener((grp, id, checked) -> {
            if (!checked) return;
            if (id == R.id.btnModeSplit) params.mode = ToneParams.MODE_SPLIT;
            else if (id == R.id.btnModeDiff) params.mode = ToneParams.MODE_DIFF;
            else params.mode = ToneParams.MODE_PROCESSED;
            updateLegend();
            gl.refresh();
        });

        findViewById(R.id.btnReset).setOnClickListener(v -> {
            params.reset();
            g.check(R.id.btnModeProc);
            syncUi();
            gl.refresh();
        });

        btnPlay.setOnClickListener(v -> {
            if (player == null) return;
            if (player.isPlaying()) player.pause(); else player.play();
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && player != null) player.seekTo(p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { userSeeking = false; }
        });
        syncUi();
    }

    private void syncUi() {
        swEnabled.setChecked(params.enabled);
        swDeep.setChecked(params.deepBlack);
        sInt.setValue(params.intensity);
        sThr.setValue(params.threshold);
        sProt.setValue(params.protect);
        updateLabels();
        updateLegend();
    }

    private void updateLabels() {
        lblInt.setText(String.format(Locale.US, "Intensidad de negros: %d%%", (int) params.intensity));
        lblThr.setText(String.format(Locale.US, "Umbral de tonos oscuros: %d%% de luminancia", (int) params.threshold));
        lblProt.setText(String.format(Locale.US, "Protección de luces y colores: %d%%", (int) params.protect));
    }

    private void updateLegend() {
        switch (params.mode) {
            case ToneParams.MODE_SPLIT:
                legend.setText("Toca o arrastra sobre la imagen: izquierda = original, derecha = procesado.");
                break;
            case ToneParams.MODE_DIFF:
                legend.setText("Magenta = píxeles modificados; gris = sin cambios. Solo deben marcarse las zonas oscuras.");
                break;
            default:
                legend.setText("Vista procesada. Prueba Deep Black para negros más agresivos (pierde detalle en sombras).");
        }
    }

    private void startVideo(Uri uri) {
        player = new ExoPlayer.Builder(this).build();
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
        player.addListener(new Player.Listener() {
            @Override public void onVideoSizeChanged(VideoSize v) {
                gl.setVideoSize(v.width, v.height, v.pixelWidthHeightRatio);
                badge.setText(v.width + "×" + v.height);
            }
            @Override public void onIsPlayingChanged(boolean playing) {
                btnPlay.setText(playing ? "Pausa" : "Reproducir");
            }
            @Override public void onPlayerError(androidx.media3.common.PlaybackException e) {
                Toast.makeText(ViewerActivity.this, "No se pudo reproducir: " + e.getErrorCodeName(), Toast.LENGTH_LONG).show();
            }
        });
        gl.useVideo();
        gl.setVideoSurfaceListener(s -> { if (player != null) player.setVideoSurface(s); });
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.setPlayWhenReady(true);
        ui.post(ticker);
    }

    private void loadImage(Uri uri) {
        io.execute(() -> {
            try {
                ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
                Bitmap bmp = ImageDecoder.decodeBitmap(src, (decoder, info, s) -> {
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    int max = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                    int sample = 1;
                    while (max / sample > 4096) sample *= 2;
                    if (sample > 1) decoder.setTargetSampleSize(sample);
                });
                runOnUiThread(() -> { if (!isDestroyed()) { gl.setImage(bmp); badge.setText(bmp.getWidth() + "×" + bmp.getHeight()); } });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "No se pudo abrir la imagen", Toast.LENGTH_LONG).show());
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        gl.onResume();
        if (player != null && wasPlaying) player.play();
    }

    @Override protected void onPause() {
        params.save(this);
        if (player != null) {
            wasPlaying = player.isPlaying();
            player.pause();
            player.setVideoSurface(null);
        }
        gl.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        io.shutdownNow();
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
