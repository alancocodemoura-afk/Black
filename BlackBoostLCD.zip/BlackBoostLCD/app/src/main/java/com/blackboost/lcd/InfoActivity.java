package com.blackboost.lcd;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InfoActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_info);
        ((TextView) findViewById(R.id.txtInfo)).setText("""
                QUÉ HACE Y QUÉ NO HACE BLACKBOOST LCD

                Tu Galaxy A14 5G tiene pantalla LCD con retroiluminación compartida: ningún software puede apagar píxeles sueltos. Lo que sí se puede es oscurecer en la imagen los tonos casi negros para que el contraste percibido mejore. El negro nunca será tan profundo como en un OLED.

                A. DENTRO DE LA APP (funciona, es lo que implementa esta APK)
                • Reproductor de video propio y visor de imágenes propio.
                • Cada fotograma se procesa en la GPU con un shader OpenGL ES: solo cambian los píxeles con luminancia por debajo del umbral. Los negros puros siguen en 0, lo claro y los colores se conservan.
                • Incluye comparación antes|después y un mapa de cambios (magenta = píxeles modificados).
                • Limitación: no reproduce contenido protegido con DRM ni video HDR con mapeo de tonos correcto.

                B. FILTRO SUPERPUESTO SOBRE OTRAS APPS (NO incluido a propósito)
                Una capa transparente (permiso "mostrar sobre otras apps") solo puede mezclar un color uniforme encima de la pantalla. No puede leer ni analizar los píxeles de abajo, así que no puede distinguir una estrella de un fondo negro: oscurecería todo por igual y bajaría también las luces. Por eso no lo ofrezco como si fuera este efecto.

                C. PROCESAR TODA LA PANTALLA (NO incluido)
                Con API públicas solo es posible capturando la pantalla con MediaProjection (pide autorización cada vez) y redibujando el resultado en una ventana superpuesta. Problemas: añade latencia y consumo en un equipo de 4 GB de RAM, la ventana que se dibuja encima captura los toques o los bloquea, las apps con FLAG_SECURE y el contenido DRM salen en negro, y la captura implica que la app ve todo lo que muestras en pantalla (privacidad). No es una función fiable ni cómoda, así que no la incluyo.

                RESUMEN
                • Global: ninguna función de esta APK.
                • Solo dentro de la app: todo el procesamiento (video, imágenes y escena de prueba).
                """);
    }
}
