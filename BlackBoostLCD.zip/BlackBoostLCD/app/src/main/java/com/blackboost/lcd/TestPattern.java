package com.blackboost.lcd;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/** Escena sintética: espacio casi negro, estrellas, planetas, persona oscura, subtítulo y rampas de sombras. */
final class TestPattern {
    private TestPattern() {}

    static Bitmap generate() {
        final int W = 1280, H = 720;
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.BLACK);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Nebulosas casi negras (la zona que BlackBoost debe oscurecer)
        p.setShader(new RadialGradient(380, 260, 420, Color.argb(255, 14, 16, 38), Color.argb(0, 14, 16, 38), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(new RadialGradient(900, 420, 380, Color.argb(255, 30, 12, 24), Color.argb(0, 30, 12, 24), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);

        // Estrellas
        Random r = new Random(7);
        for (int i = 0; i < 320; i++) {
            float x = r.nextFloat() * W, y = r.nextFloat() * H * 0.8f, rad = 0.6f + r.nextFloat() * 1.6f;
            int v = 140 + r.nextInt(116), tint = r.nextInt(3);
            p.setColor(tint == 0 ? Color.rgb(v, v, 255) : tint == 1 ? Color.rgb(255, 255, v) : Color.rgb(v, v, v));
            c.drawCircle(x, y, rad, p);
        }

        // Planetas
        p.setShader(new RadialGradient(905, 170, 90, Color.rgb(255, 190, 110), Color.rgb(120, 50, 20), Shader.TileMode.CLAMP));
        c.drawCircle(930, 200, 70, p);
        p.setShader(new RadialGradient(235, 500, 55, Color.rgb(140, 200, 255), Color.rgb(15, 40, 90), Shader.TileMode.CLAMP));
        c.drawCircle(250, 520, 42, p);
        p.setShader(null);

        // Persona: piel tenue y ropa muy oscura
        p.setColor(Color.rgb(20, 22, 28));
        c.drawRoundRect(new RectF(570, 480, 710, 640), 30, 30, p);
        p.setColor(Color.rgb(122, 86, 70));
        c.drawCircle(640, 430, 46, p);

        // Foco luminoso con halo
        p.setShader(new RadialGradient(780, 380, 60, Color.WHITE, Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
        c.drawCircle(780, 380, 60, p);
        p.setShader(null);

        // Rampa continua 0..255 y parches de sombras 0..45
        p.setShader(new LinearGradient(40, 0, 440, 0, Color.BLACK, Color.WHITE, Shader.TileMode.CLAMP));
        c.drawRect(40, 560, 440, 590, p);
        p.setShader(null);
        for (int i = 0; i < 16; i++) {
            int v = i * 3;
            p.setColor(Color.rgb(v, v, v));
            c.drawRect(40 + i * 25, 600, 40 + i * 25 + 24, 630, p);
        }
        p.setColor(Color.rgb(150, 150, 150));
        p.setTextSize(18);
        c.drawText("Rampa 0-255 y parches 0-45 (sombras)", 40, 652, p);

        // Subtítulo blanco
        p.setColor(Color.WHITE);
        p.setTextSize(40);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("Subtítulo de prueba: 1234 ABC", W / 2f, 700, p);
        return b;
    }
}
