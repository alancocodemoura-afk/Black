# BlackBoost LCD

Negros más profundos en pantallas LCD mediante una curva tonal selectiva en GPU (OpenGL ES 2.0).
Solo funciona **dentro de la app** (reproductor de video, visor de imágenes y escena de prueba).
No usa root, ni overlays, ni MediaProjection. Ver la pantalla "Qué es global y qué no" dentro de la app.

## Compilar sin PC (GitHub Actions)
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestaña **Actions** > *Build APK* > se ejecuta sola (o *Run workflow*).
3. Al terminar, abre la ejecución, baja el artefacto **BlackBoostLCD-debug** (zip) y extrae `app-debug.apk`.
4. Instala el APK (permite "instalar apps desconocidas" para tu navegador o gestor de archivos).

## Compilar con Android Studio
Abrir la carpeta, esperar la sincronización de Gradle y ejecutar *Build > Build APK(s)*.
Requiere JDK 17, AGP 8.5.2, Gradle 8.9, minSdk 28.
